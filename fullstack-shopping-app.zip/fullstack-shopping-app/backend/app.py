import os
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from passlib.hash import bcrypt

load_dotenv()

app = Flask(__name__)
CORS(app)

# Config
SECRET_KEY = os.getenv("SECRET_KEY", "secret")
DATABASE_URL = os.getenv("DATABASE_URL", "mysql+mysqldb://root:password@localhost/shopping_db")

# SQLAlchemy Engine/Session
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine)

def get_open_cart(session, user_id):
    cart = session.execute(text("SELECT * FROM carts WHERE user_id=:uid AND status='open' LIMIT 1"), {"uid": user_id}).mappings().first()
    if not cart:
        session.execute(text("INSERT INTO carts (user_id, status) VALUES (:uid, 'open')"), {"uid": user_id})
        session.commit()
        cart = session.execute(text("SELECT * FROM carts WHERE user_id=:uid AND status='open' LIMIT 1"), {"uid": user_id}).mappings().first()
    return cart

@app.get("/api/health")
def health():
    return {"status": "ok", "time": datetime.utcnow().isoformat()}

# ---------- Auth ----------
@app.post("/api/auth/register")
def register():
    data = request.get_json() or {}
    name = data.get("name")
    email = data.get("email")
    password = data.get("password")
    if not all([name, email, password]):
        return jsonify({"message": "name, email, password required"}), 400

    pwd_hash = bcrypt.hash(password)
    with SessionLocal() as s:
        # Check existing
        exists = s.execute(text("SELECT id FROM users WHERE email=:e"), {"e": email}).first()
        if exists:
            return jsonify({"message": "Email already registered"}), 409
        s.execute(text("INSERT INTO users (name, email, password_hash) VALUES (:n,:e,:p)"),
                  {"n": name, "e": email, "p": pwd_hash})
        s.commit()
        user = s.execute(text("SELECT id, name, email FROM users WHERE email=:e"), {"e": email}).mappings().first()
    return jsonify({"user": dict(user)}), 201

@app.post("/api/auth/login")
def login():
    data = request.get_json() or {}
    email = data.get("email")
    password = data.get("password")
    if not all([email, password]):
        return jsonify({"message": "email, password required"}), 400

    with SessionLocal() as s:
        row = s.execute(text("SELECT id, name, email, password_hash FROM users WHERE email=:e"), {"e": email}).mappings().first()
        if not row or not bcrypt.verify(password, row["password_hash"]):
            return jsonify({"message": "Invalid credentials"}), 401
        user = {"id": row["id"], "name": row["name"], "email": row["email"]}
    return jsonify({"user": user}), 200

# ---------- Items ----------
@app.get("/api/items")
def list_items():
    with SessionLocal() as s:
        items = s.execute(text("SELECT id, name, description, price, image_url FROM items ORDER BY id DESC")).mappings().all()
        return jsonify({"items": [dict(i) for i in items]})

# ---------- Cart ----------
@app.get("/api/cart")
def get_cart():
    user_id = request.args.get("user_id", type=int)
    if not user_id:
        return jsonify({"message": "user_id query param required"}), 400
    with SessionLocal() as s:
        cart = get_open_cart(s, user_id)
        items = s.execute(text("""
            SELECT ci.id, ci.quantity, i.id as item_id, i.name, i.price, i.image_url
            FROM cart_items ci
            JOIN items i ON ci.item_id = i.id
            WHERE ci.cart_id=:cid
        """), {"cid": cart["id"]}).mappings().all()
        return jsonify({"cart_id": cart["id"], "items": [dict(x) for x in items]})

@app.post("/api/cart/add")
def cart_add():
    data = request.get_json() or {}
    user_id = data.get("user_id")
    item_id = data.get("item_id")
    qty = int(data.get("quantity", 1))
    if not all([user_id, item_id]):
        return jsonify({"message": "user_id, item_id required"}), 400

    with SessionLocal() as s:
        cart = get_open_cart(s, user_id)
        # If item exists, increment; else insert
        existing = s.execute(text("SELECT id, quantity FROM cart_items WHERE cart_id=:cid AND item_id=:iid"),
                             {"cid": cart["id"], "iid": item_id}).mappings().first()
        if existing:
            s.execute(text("UPDATE cart_items SET quantity=:q WHERE id=:id"),
                      {"q": existing["quantity"] + qty, "id": existing["id"]})
        else:
            s.execute(text("INSERT INTO cart_items (cart_id, item_id, quantity) VALUES (:cid,:iid,:q)"),
                      {"cid": cart["id"], "iid": item_id, "q": qty})
        s.commit()
    return jsonify({"message": "added"}), 201

@app.delete("/api/cart/remove/<int:cart_item_id>")
def cart_remove(cart_item_id):
    with SessionLocal() as s:
        s.execute(text("DELETE FROM cart_items WHERE id=:id"), {"id": cart_item_id})
        s.commit()
    return jsonify({"message": "removed"}), 200

# ---------- Checkout ----------
@app.post("/api/checkout")
def checkout():
    data = request.get_json() or {}
    user_id = data.get("user_id")
    if not user_id:
        return jsonify({"message": "user_id required"}), 400

    with SessionLocal() as s:
        cart = get_open_cart(s, user_id)
        items = s.execute(text("""
            SELECT ci.id, ci.quantity, i.id as item_id, i.price
            FROM cart_items ci
            JOIN items i ON ci.item_id = i.id
            WHERE ci.cart_id=:cid
        """), {"cid": cart["id"]}).mappings().all()

        if not items:
            return jsonify({"message": "cart empty"}), 400

        total = sum([row["quantity"] * float(row["price"]) for row in items])

        # Create order
        s.execute(text("INSERT INTO orders (user_id, total) VALUES (:uid, :t)"),
                  {"uid": user_id, "t": total})
        order = s.execute(text("SELECT * FROM orders WHERE user_id=:uid ORDER BY id DESC LIMIT 1"),
                          {"uid": user_id}).mappings().first()

        # Insert order items
        for row in items:
            s.execute(text("""
                INSERT INTO order_items (order_id, item_id, quantity, price_at_purchase)
                VALUES (:oid, :iid, :q, :p)
            """), {"oid": order["id"], "iid": row["item_id"], "q": row["quantity"], "p": float(row["price"])})
        # Clear cart
        s.execute(text("DELETE FROM cart_items WHERE cart_id=:cid"), {"cid": cart["id"]})
        s.execute(text("UPDATE carts SET status='checked_out' WHERE id=:cid"), {"cid": cart["id"]})
        s.commit()

    return jsonify({"message": "checked out", "order_id": order["id"], "total": total}), 201

if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    host = os.getenv("HOST", "0.0.0.0")
    app.run(host=host, port=port, debug=True)
