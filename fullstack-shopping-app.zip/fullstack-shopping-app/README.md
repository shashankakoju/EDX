# Fullstack Shopping App (React + Flask + MySQL)

A minimal, clean starter with:
- React (Vite) frontend
- Flask backend (SQLAlchemy + MySQL)
- `database/schema.sql` to create tables and seed sample data

## Quick Start

### 1) Create DB and sample data
- Create a database (e.g. `shopping_db`) in MySQL.
- Run the SQL in `database/schema.sql`.

### 2) Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your MySQL credentials
flask run --host=0.0.0.0 --port=5000
```

### 3) Frontend
```bash
cd frontend
npm install
npm run dev
```

By default, the frontend expects the API at `http://localhost:5000`.

## Features
- Auth: register / login (simple demo with hashed passwords)
- Items: list items
- Cart: add/remove items, view cart, checkout (creates order + empties cart)

## Notes
- This is a starter template — feel free to expand it with JWT, validations, etc.
