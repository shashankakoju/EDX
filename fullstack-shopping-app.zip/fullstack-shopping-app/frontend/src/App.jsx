import React, { useEffect, useState } from 'react'
import { api } from './services/api'
import Login from './components/Login'
import Items from './components/Items'
import Cart from './components/Cart'

export default function App(){
  const [user, setUser] = useState(null)
  const [items, setItems] = useState([])
  const [cart, setCart] = useState({ items: [] })

  useEffect(()=>{
    api.items().then(res => setItems(res.data.items))
  }, [])

  const handleLogin = async (email, password) => {
    const res = await api.login({ email, password })
    setUser(res.data.user)
    // After login, fetch cart
    const cartRes = await api.getCart(res.data.user.id)
    setCart(cartRes.data)
  }

  const handleRegister = async (name, email, password) => {
    const res = await api.register({ name, email, password })
    setUser(res.data.user)
    const cartRes = await api.getCart(res.data.user.id)
    setCart(cartRes.data)
  }

  const addToCart = async (itemId) => {
    if(!user){ alert('Please login first'); return; }
    await api.addToCart({ user_id: user.id, item_id: itemId, quantity: 1 })
    const cartRes = await api.getCart(user.id)
    setCart(cartRes.data)
  }

  const removeCartItem = async (cartItemId) => {
    await api.removeFromCart(cartItemId)
    const cartRes = await api.getCart(user.id)
    setCart(cartRes.data)
  }

  const checkout = async () => {
    if(!user){ alert('Please login first'); return; }
    const res = await api.checkout({ user_id: user.id })
    alert('Order #' + res.data.order_id + ' placed. Total: ₹' + res.data.total)
    const cartRes = await api.getCart(user.id)
    setCart(cartRes.data)
  }

  return (
    <div className="container">
      <h1>🛒 Shopping App</h1>
      <p className="muted">React + Flask + MySQL</p>

      <div className="row">
        <Login onLogin={handleLogin} onRegister={handleRegister} user={user} />
      </div>

      <div className="space" />

      <div className="card">
        <h2>Items</h2>
        <Items items={items} onAdd={addToCart} />
      </div>

      <div className="card">
        <h2>Cart</h2>
        <Cart cart={cart} onRemove={removeCartItem} onCheckout={checkout} />
      </div>
    </div>
  )
}
