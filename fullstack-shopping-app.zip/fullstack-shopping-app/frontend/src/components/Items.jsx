import React from 'react'

export default function Items({ items, onAdd }){
  if(!items.length) return <p className="muted">No items yet.</p>
  return (
    <ul>
      {items.map(it => (
        <li key={it.id} className="row">
          <img src={it.image_url} alt={it.name} width="60" height="60" style={{borderRadius: 8}} />
          <div style={{flex: 1}}>
            <div><b>{it.name}</b></div>
            <div className="muted">{it.description}</div>
          </div>
          <div>₹{it.price}</div>
          <button onClick={()=>onAdd(it.id)}>Add</button>
        </li>
      ))}
    </ul>
  )
}
