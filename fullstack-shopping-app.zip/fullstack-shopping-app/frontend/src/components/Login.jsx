import React, { useState } from 'react'

export default function Login({ onLogin, onRegister, user }){
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  if(user){
    return <div className="card">Logged in as <b>{user.name}</b> ({user.email})</div>
  }

  return (
    <div className="card" style={{flex: 1}}>
      <h2>Login / Register</h2>
      <div className="row">
        <input placeholder="Name (for register)" value={name} onChange={e=>setName(e.target.value)} />
        <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      </div>
      <div className="row" style={{marginTop: '0.5rem'}}>
        <button onClick={()=>onLogin(email, password)}>Login</button>
        <button onClick={()=>onRegister(name, email, password)}>Register</button>
      </div>
    </div>
  )
}
