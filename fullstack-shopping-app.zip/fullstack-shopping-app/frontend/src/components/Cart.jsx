import React from 'react'

export default function Cart({ cart, onRemove, onCheckout }){
  const items = cart?.items || []
  const total = items.reduce((acc, it) => acc + it.quantity * it.price, 0)

  return (
    <div>
      {items.length === 0 ? <p className="muted">Your cart is empty.</p> : (
        <ul>
          {items.map(ci => (
            <li key={ci.id} className="row">
              <img src={ci.image_url} alt={ci.name} width="40" height="40" style={{borderRadius: 8}}/>
              <div style={{flex: 1}}>
                <div><b>{ci.name}</b> × {ci.quantity}</div>
              </div>
              <div>₹{(ci.price * ci.quantity).toFixed(2)}</div>
              <button onClick={()=>onRemove(ci.id)}>Remove</button>
            </li>
          ))}
        </ul>
      )}

      <div className="row" style={{justifyContent:'space-between', marginTop:'1rem'}}>
        <b>Total: ₹{total.toFixed(2)}</b>
        <button onClick={onCheckout} disabled={items.length===0}>Checkout</button>
      </div>
    </div>
  )
}
