import './styles/style.css';
import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Register from './components/Register';
import Login from './components/Login';
import Profile from './components/Profile';
import UserList from './components/UserList';
function App(){
  return (
    <BrowserRouter>
      <div className="container py-4">
        <h2>UserProfileLogin</h2>
        <nav className="mb-3">
          <Link className="me-2" to="/">Register</Link>
          <Link className="me-2" to="/login">Login</Link>
          <Link to="/users">UserList</Link>
        </nav>
        <Routes>
          <Route path="/" element={<Register/>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/profile" element={<Profile/>} />
          <Route path="/users" element={<UserList/>} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}
export default App;
