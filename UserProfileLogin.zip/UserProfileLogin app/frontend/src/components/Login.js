import React, { useState } from 'react';
import { loginUser } from '../api';

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); // clear previous errors

    try {
      const data = await loginUser(form);
      console.log('Login success:', data);
      localStorage.setItem('token', data.token);

      // Optional: redirect or show success
      alert(data.message);
      // navigate('/dashboard');  // if using React Router
    } catch (err) {
      console.error('Login Error:', err.response?.data || err.message);
      setError(err.response?.data?.message || 'Something went wrong.');
    }
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      {error && (
        <div style={{ background: '#cce5ff', padding: '10px', borderRadius: '6px' }}>
          {error}
        </div>
      )}
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          required
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={form.password}
          onChange={handleChange}
          required
        />
        <button type="submit">Login</button>
      </form>
    </div>
  );
}

