import React, { useEffect, useState } from 'react';
import { getUserProfile } from '../api';

export default function Profile() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    async function fetchProfile() {
      const data = await getUserProfile();
      setUser(data);
    }
    fetchProfile();
  }, []);

  if (!user) return <p>Loading...</p>;

  return (
    <div className="container">
      <div className="profile">
        <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="Profile" />
        <h2>{user.name}</h2>
        <p>{user.email}</p>
      </div>
    </div>
  );
}

