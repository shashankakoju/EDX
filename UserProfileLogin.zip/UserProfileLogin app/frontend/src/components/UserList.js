import React, { useEffect, useState } from 'react';
import { getAllUsers } from '../api';

export default function UserList() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    async function fetchUsers() {
      const token = localStorage.getItem("token");
      console.log("Token being sent:", token);
      const data = await getAllUsers(token);
      setUsers(data || []);
    }
    fetchUsers();
  }, []);

  return (
    <div className="container">
      <div className="card">
        <h2>User List</h2>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u, index) => (
              <tr key={index}>
                <td>{u.name}</td>
                <td>{u.email}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
