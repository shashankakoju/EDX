import axios from 'axios';

// Base URLs
const AUTH_URL = 'http://localhost:5000/api/auth';
const USER_URL = 'http://localhost:5000/api/users';

// --- AUTH related --- //
export const registerUser = async (userData) => {
  try {
    const response = await axios.post(`${AUTH_URL}/register`, userData);
    return response.data;
  } catch (error) {
    console.error('Register Error:', error);
    throw error;
  }
};

export const loginUser = async (credentials) => {
  try {
    const response = await axios.post(`${AUTH_URL}/login`, credentials);
    return response.data;
  } catch (error) {
    console.error('Login Error:', error);
    throw error;
  }
};

// --- USER related --- //
export const getUserProfile = async (token) => {
  try {
    const response = await axios.get(`${USER_URL}/profile`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  } catch (error) {
    console.error('Get Profile Error:', error);
    throw error;
  }
};

export const getAllUsers = async (token) => {
  try {
    const response = await axios.get(`${USER_URL}/`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  } catch (error) {
    console.error('Get All Users Error:', error);
    throw error;
  }
};

// ✅ Optional default export (in case other files use API.*)
export default {
  registerUser,
  loginUser,
  getUserProfile,
  getAllUsers,
};


