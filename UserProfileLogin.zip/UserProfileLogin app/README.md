UserProfileLogin
=================
Full-stack React + Node.js + Express + MySQL project with JWT auth.

Setup:
1. Import database: mysql -u root -p < database/userdb.sql
2. Backend:
   cd backend
   cp .env.example .env   # then edit .env with your DB credentials
   npm install
   npm run dev
3. Frontend:
   cd frontend
   npm install
   npm start
