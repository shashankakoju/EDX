// simple model helpers for users table using mysql2
const db = require('../config/db');
module.exports = {
  create: async (name, email, password) => {
    const [res] = await db.execute('INSERT INTO users (name,email,password) VALUES (?,?,?)', [name,email,password]);
    return { id: res.insertId, name, email };
  },
  findByEmail: async (email) => {
    const [rows] = await db.execute('SELECT * FROM users WHERE email = ?', [email]);
    return rows[0];
  },
  findById: async (id) => {
    const [rows] = await db.execute('SELECT id,name,email,created_at FROM users WHERE id = ?', [id]);
    return rows[0];
  },
  findAll: async () => {
    const [rows] = await db.execute('SELECT id,name,email,created_at FROM users ORDER BY id DESC');
    return rows;
  },
  update: async (id, name, email) => {
    await db.execute('UPDATE users SET name = ?, email = ? WHERE id = ?', [name, email, id]);
    return module.exports.findById(id);
  },
  remove: async (id) => {
    await db.execute('DELETE FROM users WHERE id = ?', [id]);
    return;
  }
};
