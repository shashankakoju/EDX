const User = require('../models/User');
module.exports = {
  me: async (req,res) => {
    try{
      const user = await User.findById(req.userId);
      if(!user) return res.status(404).json({message:'User not found'});
      res.json(user);
    }catch(err){ console.error(err); res.status(500).json({message:'Server error'}); }
  },
  all: async (req,res) => {
    try{
      const users = await User.findAll();
      res.json(users);
    }catch(err){ console.error(err); res.status(500).json({message:'Server error'}); }
  },
  update: async (req,res) => {
    try{
      const id = req.params.id;
      const { name, email } = req.body;
      const updated = await User.update(id, name, email);
      res.json(updated);
    }catch(err){ console.error(err); res.status(500).json({message:'Server error'}); }
  },
  remove: async (req,res) => {
    try{
      const id = req.params.id;
      await User.remove(id);
      res.json({message:'User deleted'});
    }catch(err){ console.error(err); res.status(500).json({message:'Server error'}); }
  }
};
