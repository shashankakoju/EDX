Backend README
----------------
1. Copy .env.example to .env and update DB credentials.
2. Run: npm install
3. Start server: npm run dev
API endpoints:
POST /api/auth/register
POST /api/auth/login
GET  /api/users        (protected)
GET  /api/users/me     (protected)
PUT  /api/users/:id    (protected)
DELETE /api/users/:id  (protected)
