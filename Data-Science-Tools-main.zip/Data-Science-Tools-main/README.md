# Applied-Data-Science-Capstone
Part of the IBM Data Science Professional Certificate, multiple assignments for course 10 out of 10

* 1 - Hands-on_Lab_Complete_the_Data_Collection_API_Lab.ipynb(https://github.com/rohith538/Data-Science-and-Machine-Learning-Capstone-Project/blob/main/Hands-on_Lab_Complete_the_Data_Collection_API_Lab.ipynb)
* 2 - dataset_part_1.csv(https://github.com/rohith538/Data-Science-and-Machine-Learning-Capstone-Project/blob/main/dataset_part_1.csv)
* 3 - Hands-on_Lab_Complete_the_Collection_with_Web_Scraping_lab.ipynb(https://github.com/rohith538/Data-Science-and-Machine-Learning-Capstone-Project/blob/main/Hands-on_Lab_Complete_the_Collection_with_Web_Scraping_lab.ipynb)
* 4 - spacex_web_scraped.csv(https://github.com/rohith538/Data-Science-and-Machine-Learning-Capstone-Project/blob/main/spacex_web_scraped.csv)
* 5 - Hands-on_Lab_Data_Wrangling.ipynb(https://github.com/rohith538/Data-Science-and-Machine-Learning-Capstone-Project/blob/main/Hands-on_Lab_Data_Wrangling.ipynb)
* 6 - dataset_part_2.csv(https://github.com/rohith538/Data-Science-and-Machine-Learning-Capstone-Project/blob/main/dataset_part_2.csv)
* 7 - Hands-on_Lab_Complete_the_EDA_with_SQL.ipynb(https://github.com/rohith538/Data-Science-and-Machine-Learning-Capstone-Project/blob/main/Hands-on_Lab_Complete_the_EDA_with_SQL.ipynb)
* 8 - my_data1.db(https://github.com/rohith538/Data-Science-and-Machine-Learning-Capstone-Project/blob/main/my_data1.db)
* 9 - Spacex.csv(https://github.com/rohith538/Data-Science-and-Machine-Learning-Capstone-Project/blob/main/Spacex.csv)
* 10 - Hands-on_Lab_Complete_the_EDA_with_Visualization.ipynb(https://github.com/rohith538/Data-Science-and-Machine-Learning-Capstone-Project/blob/main/Hands-on_Lab_Complete_the_EDA_with_Visualization.ipynb)
* 11 - dataset_part_3.csv(https://github.com/rohith538/Data-Science-and-Machine-Learning-Capstone-Project/blob/main/dataset_part_3.csv)
* 12 - Hands-on_Lab_Interactive_Visual_Analytics_with_Folium_lab.ipynb(https://github.com/rohith538/Data-Science-and-Machine-Learning-Capstone-Project/blob/main/Hands-on_Lab_Interactive_Visual_Analytics_with_Folium_lab.ipynb)
* 13 - spacex_dash_app.py(https://github.com/rohith538/Data-Science-and-Machine-Learning-Capstone-Project/blob/main/spacex_dash_app.py)
* 14 - spacex_launch_dash.csv(https://github.com/rohith538/Data-Science-and-Machine-Learning-Capstone-Project/blob/main/spacex_launch_dash.csv)
* 15 - Hands-on_Lab_Complete_the_Machine_Learning_Prediction_lab.ipynb(https://github.com/rohith538/Data-Science-and-Machine-Learning-Capstone-Project/blob/main/Hands-on_Lab_Complete_the_Machine_Learning_Prediction_lab.ipynb)
